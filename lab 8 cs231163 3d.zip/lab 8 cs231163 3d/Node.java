class Node
{
    int key;
    Node left,right;

    public Node (int item) {
        key = item;
        left = right = null;
    }
}
class BinaryTreeTask {
    Node root;

    BinaryTreeTask(int key) {
        root = new Node(key);
    }
    BinaryTreeTask()
    {
        root = null;
    }

    public void Preorder(Node node) {
        if (node == null) {
            return;
        }
        System.out.print(node.key + " ");
        Preorder(node.left);
        Preorder(node.right);
    }

    public void Inorder(Node node) {
        if (node == null) {
            return;
        }
        Inorder(node.left);
        System.out.print(node.key + " ");
        Inorder(node.right);
    }

    public void Postorder(Node node) {
        if (node == null) {
            return;
        }
        Postorder(node.left);
        Postorder(node.right);
        System.out.print(node.key + " ");
    }

    public static void main(String[] args) {

        BinaryTreeTask tree = new BinaryTreeTask();

        tree.root = new Node(1);
        Node a = new Node(2);
        tree.root.left = a;
        Node b = new Node(3);
        tree.root.right = b;

        a.left = new Node(4);
        b.right = new Node(5);

        System.out.println("Pre-order");
        tree.Preorder(tree.root);

        System.out.println("\nPost-order");
        tree.Postorder(tree.root);

        System.out.println("\nIn-order");
        tree.Inorder(tree.root);
    }
}
